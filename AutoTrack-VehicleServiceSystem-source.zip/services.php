<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$search = trim($_GET['q'] ?? '');
$status = trim($_GET['status'] ?? '');
$validStatuses = ['Pending', 'In Progress', 'Completed'];

$sql = '
    SELECT s.*, v.reg_number, v.make, v.model, c.full_name AS customer_name
    FROM services s
    JOIN vehicles v ON v.id = s.vehicle_id
    JOIN customers c ON c.id = v.customer_id
    WHERE 1=1
';
$params = [];

if ($search !== '') {
    $sql .= ' AND (v.reg_number LIKE ? OR c.full_name LIKE ? OR s.service_type LIKE ? OR s.mechanic LIKE ?) ';
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like);
}
if (in_array($status, $validStatuses, true)) {
    $sql .= ' AND s.status = ? ';
    $params[] = $status;
}
$sql .= ' ORDER BY s.service_date DESC, s.id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$services = $stmt->fetchAll();

function statusBadgeClass(string $s): string
{
    return match ($s) {
        'Completed' => 'badge-completed',
        'In Progress' => 'badge-progress',
        default => 'badge-pending',
    };
}

$pageTitle = 'Service Records';
$activeNav = 'services';
require __DIR__ . '/includes/header.php';
?>

<div class="search-bar">
  <form method="get" style="display:flex; gap:10px; flex-wrap:wrap;">
    <input type="text" name="q" placeholder="Search reg. number, customer, service type&hellip;" value="<?= e($search) ?>">
    <select name="status">
      <option value="">All Statuses</option>
      <?php foreach ($validStatuses as $s): ?>
        <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-outline">Filter</button>
    <?php if ($search !== '' || $status !== ''): ?><a href="services.php" class="btn btn-outline">Clear</a><?php endif; ?>
  </form>
  <a href="service_add.php" class="btn btn-amber" style="margin-left:auto;">+ Log Service</a>
</div>

<div class="card">
  <div class="card-body" style="padding:0;">
    <?php if (empty($services)): ?>
      <div class="empty-state">
        <div class="glyph">&#128295;</div>
        <?= ($search !== '' || $status !== '') ? 'No service records match your filters.' : 'No service records logged yet.' ?>
      </div>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>Date</th><th>Vehicle</th><th>Customer</th><th>Service Type</th><th>Mechanic</th><th>Cost</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($services as $s): ?>
            <tr>
              <td><?= e(date('d M Y', strtotime($s['service_date']))) ?></td>
              <td><span class="reg-plate"><?= e($s['reg_number']) ?></span></td>
              <td><?= e($s['customer_name']) ?></td>
              <td><?= e($s['service_type']) ?></td>
              <td><?= e($s['mechanic']) ?></td>
              <td class="mono">GH&#8373;<?= number_format((float)$s['cost'], 2) ?></td>
              <td><span class="badge <?= statusBadgeClass($s['status']) ?>"><?= e($s['status']) ?></span></td>
              <td class="row-actions">
                <a href="service_edit.php?id=<?= (int)$s['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                <form method="post" action="service_delete.php" onsubmit="return confirmDelete('Delete this service record?');" style="display:inline;">
                  <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
