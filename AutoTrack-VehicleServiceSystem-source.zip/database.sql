-- =====================================================================
-- Vehicle Service Management System
-- Database export for MySQL / MariaDB
-- Accra Technical University — BCP 206, Web Development Technologies II
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `vehicle_service_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `vehicle_service_db`;

-- ---------------------------------------------------------------------
-- Table: admins  (system users who may log in to manage the centre)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name`     VARCHAR(100) NOT NULL,
  `username`      VARCHAR(50)  NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admins_username` (`username`)
) ENGINE=InnoDB;

-- Default admin login → username: admin   password: Admin@123
-- (hash generated with PHP password_hash(), bcrypt)
INSERT INTO `admins` (`full_name`, `username`, `password_hash`) VALUES
('System Administrator', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.YeIVeYzL3G3RyMEB.6yhAM.b/Q5aSy2R2');

-- ---------------------------------------------------------------------
-- Table: customers
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name`  VARCHAR(100) NOT NULL,
  `phone`      VARCHAR(20)  NOT NULL,
  `email`      VARCHAR(100) DEFAULT NULL,
  `address`    VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_phone` (`phone`)
) ENGINE=InnoDB;

INSERT INTO `customers` (`full_name`, `phone`, `email`, `address`) VALUES
('Kwame Owusu',      '0244123456', 'kwame.owusu@example.com',   'East Legon, Accra'),
('Ama Serwaa',        '0209988776', 'ama.serwaa@example.com',    'Tema Community 5'),
('Yaw Boateng',       '0277456123', 'yaw.boateng@example.com',   'Kasoa, Central Region'),
('Efua Mensah',       '0554321098', NULL,                        'Adenta, Accra');

-- ---------------------------------------------------------------------
-- Table: vehicles  (each vehicle belongs to one customer)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`  INT UNSIGNED NOT NULL,
  `reg_number`   VARCHAR(20)  NOT NULL,
  `make`         VARCHAR(50)  NOT NULL,
  `model`        VARCHAR(50)  NOT NULL,
  `year`         SMALLINT UNSIGNED NOT NULL,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vehicles_reg_number` (`reg_number`),
  KEY `idx_vehicles_customer_id` (`customer_id`),
  CONSTRAINT `fk_vehicles_customer`
    FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO `vehicles` (`customer_id`, `reg_number`, `make`, `model`, `year`) VALUES
(1, 'GR 1234-24', 'Toyota',   'Corolla',  2019),
(1, 'GT 5588-21', 'Honda',    'CR-V',     2021),
(2, 'GW 9021-20', 'Nissan',   'Almera',   2018),
(3, 'GE 3345-22', 'Kia',      'Rio',      2020),
(4, 'GS 7712-23', 'Hyundai',  'Elantra',  2022);

-- ---------------------------------------------------------------------
-- Table: services  (each service record belongs to one vehicle)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `vehicle_id`    INT UNSIGNED NOT NULL,
  `service_date`  DATE NOT NULL,
  `service_type`  VARCHAR(100) NOT NULL,
  `mechanic`      VARCHAR(100) NOT NULL,
  `cost`          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status`        ENUM('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  `notes`         VARCHAR(255) DEFAULT NULL,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_services_vehicle_id` (`vehicle_id`),
  CONSTRAINT `fk_services_vehicle`
    FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO `services` (`vehicle_id`, `service_date`, `service_type`, `mechanic`, `cost`, `status`, `notes`) VALUES
(1, '2026-06-02', 'Oil Change & Filter',        'Kojo Ansah',   180.00, 'Completed',  'Used synthetic oil'),
(1, '2026-07-10', 'Brake Pad Replacement',      'Kojo Ansah',   420.00, 'In Progress','Front pads only'),
(2, '2026-06-20', 'Full Service',               'Nana Yeboah',  950.00, 'Completed',  NULL),
(3, '2026-07-05', 'Wheel Alignment & Balancing','Kojo Ansah',   250.00, 'Pending',    NULL),
(4, '2026-06-28', 'AC Repair',                  'Nana Yeboah',  600.00, 'Completed',  'Compressor recharge'),
(5, '2026-07-14', 'Battery Replacement',        'Kojo Ansah',   380.00, 'Pending',    NULL);

SET FOREIGN_KEY_CHECKS = 1;
