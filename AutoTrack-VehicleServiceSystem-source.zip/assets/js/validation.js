/**
 * Client-side validation for the Vehicle Service Management System.
 * Attaches to any <form data-validate> and checks fields marked with
 * data-rule="..." before allowing submission. Server-side validation
 * in PHP is the real authority; this just gives instant feedback.
 */

document.addEventListener('DOMContentLoaded', function () {
  var forms = document.querySelectorAll('form[data-validate]');
  forms.forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!validateForm(form)) {
        e.preventDefault();
      }
    });

    // Re-validate a field as the user leaves it.
    form.querySelectorAll('[data-rule]').forEach(function (field) {
      field.addEventListener('blur', function () { validateField(field); });
    });
  });
});

function validateForm(form) {
  var valid = true;
  form.querySelectorAll('[data-rule]').forEach(function (field) {
    if (!validateField(field)) valid = false;
  });
  return valid;
}

function validateField(field) {
  var rules = field.getAttribute('data-rule').split('|');
  var value = field.value.trim();
  var errorEl = document.getElementById(field.id + '-error');
  var message = '';

  for (var i = 0; i < rules.length; i++) {
    var rule = rules[i];
    var param = null;
    if (rule.indexOf(':') !== -1) {
      var parts = rule.split(':');
      rule = parts[0];
      param = parts[1];
    }

    if (rule === 'required' && value === '') {
      message = 'This field is required.';
      break;
    }
    if (rule === 'phone' && value !== '' && !/^0[0-9]{9}$/.test(value)) {
      message = 'Enter a valid 10-digit phone number (e.g. 0244123456).';
      break;
    }
    if (rule === 'email' && value !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      message = 'Enter a valid email address.';
      break;
    }
    if (rule === 'regnumber' && value !== '' && !/^[A-Z]{2}\s?\d{3,4}-?\d{2}$/i.test(value)) {
      message = 'Use the format GR 1234-24.';
      break;
    }
    if (rule === 'number' && value !== '' && isNaN(Number(value))) {
      message = 'Enter a valid number.';
      break;
    }
    if (rule === 'min' && value !== '' && Number(value) < Number(param)) {
      message = 'Value must be at least ' + param + '.';
      break;
    }
    if (rule === 'max' && value !== '' && Number(value) > Number(param)) {
      message = 'Value must be at most ' + param + '.';
      break;
    }
    if (rule === 'minlength' && value !== '' && value.length < Number(param)) {
      message = 'Enter at least ' + param + ' characters.';
      break;
    }
  }

  if (message) {
    field.classList.add('invalid');
    if (errorEl) errorEl.textContent = message;
    return false;
  } else {
    field.classList.remove('invalid');
    if (errorEl) errorEl.textContent = '';
    return true;
  }
}

/** Simple confirm-before-delete helper used on list pages. */
function confirmDelete(message) {
  return confirm(message || 'Are you sure you want to delete this record? This cannot be undone.');
}
