<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM vehicles WHERE id = ?');
$stmt->execute([$id]);
$vehicle = $stmt->fetch();

if (!$vehicle) {
    flash_set('error', 'Vehicle not found.');
    header('Location: vehicles.php');
    exit;
}

$customers = $pdo->query('SELECT id, full_name FROM customers ORDER BY full_name')->fetchAll();

$errors = [];
$data = $vehicle;
$currentYear = (int) date('Y');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors['general'] = 'Your session expired. Please try again.';
    } else {
        $data['customer_id'] = (int) ($_POST['customer_id'] ?? 0);
        $data['reg_number']  = strtoupper(trim($_POST['reg_number'] ?? ''));
        $data['make']        = trim($_POST['make'] ?? '');
        $data['model']       = trim($_POST['model'] ?? '');
        $data['year']        = trim($_POST['year'] ?? '');

        if ($data['customer_id'] <= 0) $errors['customer_id'] = 'Select the vehicle owner.';
        if ($data['reg_number'] === '') $errors['reg_number'] = 'Enter the registration number.';
        if ($data['make'] === '') $errors['make'] = 'Enter the vehicle make.';
        if ($data['model'] === '') $errors['model'] = 'Enter the vehicle model.';
        if (!ctype_digit((string)$data['year']) || (int)$data['year'] < 1980 || (int)$data['year'] > $currentYear + 1) {
            $errors['year'] = "Enter a valid year between 1980 and " . ($currentYear + 1) . '.';
        }

        if (empty($errors)) {
            $dup = $pdo->prepare('SELECT id FROM vehicles WHERE reg_number = ? AND id <> ?');
            $dup->execute([$data['reg_number'], $id]);
            if ($dup->fetch()) {
                $errors['reg_number'] = 'Another vehicle already uses this registration number.';
            }
        }

        if (empty($errors)) {
            $upd = $pdo->prepare('UPDATE vehicles SET customer_id=?, reg_number=?, make=?, model=?, year=? WHERE id=?');
            $upd->execute([$data['customer_id'], $data['reg_number'], $data['make'], $data['model'], (int)$data['year'], $id]);
            flash_set('success', 'Vehicle details updated.');
            header('Location: vehicles.php');
            exit;
        }
    }
}

$pageTitle = 'Edit Vehicle';
$activeNav = 'vehicles';
require __DIR__ . '/includes/header.php';
?>

<div class="ticket" style="max-width:640px;">
  <div class="card-body">
    <?php if (!empty($errors['general'])): ?><div class="flash error"><?= e($errors['general']) ?></div><?php endif; ?>

    <form method="post" data-validate novalidate>
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

      <div class="form-grid">
        <div class="field full">
          <label for="customer_id">Owner</label>
          <select id="customer_id" name="customer_id" data-rule="required" class="<?= isset($errors['customer_id']) ? 'invalid' : '' ?>">
            <?php foreach ($customers as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= (string)$data['customer_id'] === (string)$c['id'] ? 'selected' : '' ?>>
                <?= e($c['full_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="field-error"><?= e($errors['customer_id'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="reg_number">Registration Number</label>
          <input type="text" id="reg_number" name="reg_number" class="mono <?= isset($errors['reg_number']) ? 'invalid' : '' ?>"
                 data-rule="required|regnumber" value="<?= e($data['reg_number']) ?>">
          <div class="field-error" id="reg_number-error"><?= e($errors['reg_number'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="year">Year</label>
          <input type="number" id="year" name="year" data-rule="required|number|min:1980|max:<?= $currentYear+1 ?>"
                 class="<?= isset($errors['year']) ? 'invalid' : '' ?>" value="<?= e($data['year']) ?>">
          <div class="field-error" id="year-error"><?= e($errors['year'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="make">Make</label>
          <input type="text" id="make" name="make" data-rule="required"
                 class="<?= isset($errors['make']) ? 'invalid' : '' ?>" value="<?= e($data['make']) ?>">
          <div class="field-error" id="make-error"><?= e($errors['make'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="model">Model</label>
          <input type="text" id="model" name="model" data-rule="required"
                 class="<?= isset($errors['model']) ? 'invalid' : '' ?>" value="<?= e($data['model']) ?>">
          <div class="field-error" id="model-error"><?= e($errors['model'] ?? '') ?></div>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-amber">Update Vehicle</button>
        <a href="vehicles.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
