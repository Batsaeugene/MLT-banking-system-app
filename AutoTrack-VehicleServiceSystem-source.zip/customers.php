<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$search = trim($_GET['q'] ?? '');

if ($search !== '') {
    $stmt = $pdo->prepare('
        SELECT c.*, (SELECT COUNT(*) FROM vehicles v WHERE v.customer_id = c.id) AS vehicle_count
        FROM customers c
        WHERE c.full_name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?
        ORDER BY c.full_name
    ');
    $like = "%$search%";
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = $pdo->query('
        SELECT c.*, (SELECT COUNT(*) FROM vehicles v WHERE v.customer_id = c.id) AS vehicle_count
        FROM customers c ORDER BY c.full_name
    ');
}
$customers = $stmt->fetchAll();

$pageTitle = 'Customers';
$activeNav = 'customers';
require __DIR__ . '/includes/header.php';
?>

<div class="search-bar">
  <form method="get" style="display:flex; gap:10px;">
    <input type="text" name="q" placeholder="Search name, phone, or email&hellip;" value="<?= e($search) ?>">
    <button type="submit" class="btn btn-outline">Search</button>
    <?php if ($search !== ''): ?><a href="customers.php" class="btn btn-outline">Clear</a><?php endif; ?>
  </form>
  <a href="customer_add.php" class="btn btn-amber" style="margin-left:auto;">+ Register Customer</a>
</div>

<div class="card">
  <div class="card-body" style="padding:0;">
    <?php if (empty($customers)): ?>
      <div class="empty-state">
        <div class="glyph">&#128100;</div>
        <?= $search !== '' ? 'No customers match your search.' : 'No customers registered yet.' ?>
      </div>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>Name</th><th>Phone</th><th>Email</th><th>Address</th><th>Vehicles</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($customers as $c): ?>
            <tr>
              <td><strong><?= e($c['full_name']) ?></strong></td>
              <td class="mono"><?= e($c['phone']) ?></td>
              <td><?= e($c['email'] ?: '&mdash;') ?></td>
              <td><?= e($c['address'] ?: '&mdash;') ?></td>
              <td><?= (int)$c['vehicle_count'] ?></td>
              <td class="row-actions">
                <a href="customer_edit.php?id=<?= (int)$c['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                <form method="post" action="customer_delete.php" onsubmit="return confirmDelete('Delete this customer and all their vehicles/service records?');" style="display:inline;">
                  <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
