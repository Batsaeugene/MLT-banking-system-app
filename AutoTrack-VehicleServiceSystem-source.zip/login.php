<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

// Already logged in? Go straight to the dashboard.
if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {
            $errors[] = 'Please enter both username and password.';
        } else {
            $stmt = $pdo->prepare('SELECT id, full_name, username, password_hash FROM admins WHERE username = ?');
            $stmt->execute([$username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                header('Location: index.php');
                exit;
            }
            $errors[] = 'Incorrect username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Log In · AutoTrack Garage</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-brand">Auto<span>Track</span></div>
    <div class="login-sub">Service Centre Admin</div>

    <?php foreach ($errors as $err): ?>
      <div class="flash error"><?= e($err) ?></div>
    <?php endforeach; ?>

    <form method="post" data-validate novalidate>
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

      <div class="field" style="margin-bottom:16px;">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" data-rule="required"
               value="<?= e($_POST['username'] ?? '') ?>" autofocus>
        <div class="field-error" id="username-error"></div>
      </div>

      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" data-rule="required">
        <div class="field-error" id="password-error"></div>
      </div>

      <button type="submit" class="btn btn-amber">Log In</button>
    </form>

    <div class="login-hint">Default login &mdash; username: <strong>admin</strong> &nbsp;password: <strong>Admin@123</strong></div>
  </div>
</div>
<script src="assets/js/validation.js"></script>
</body>
</html>
