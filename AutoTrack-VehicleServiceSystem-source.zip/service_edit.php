<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM services WHERE id = ?');
$stmt->execute([$id]);
$service = $stmt->fetch();

if (!$service) {
    flash_set('error', 'Service record not found.');
    header('Location: services.php');
    exit;
}

$vehicles = $pdo->query('
    SELECT v.id, v.reg_number, v.make, v.model, c.full_name AS owner_name
    FROM vehicles v JOIN customers c ON c.id = v.customer_id
    ORDER BY v.reg_number
')->fetchAll();

$statuses = ['Pending', 'In Progress', 'Completed'];
$errors = [];
$data = $service;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors['general'] = 'Your session expired. Please try again.';
    } else {
        $data['vehicle_id']    = (int) ($_POST['vehicle_id'] ?? 0);
        $data['service_date']  = trim($_POST['service_date'] ?? '');
        $data['service_type']  = trim($_POST['service_type'] ?? '');
        $data['mechanic']      = trim($_POST['mechanic'] ?? '');
        $data['cost']          = trim($_POST['cost'] ?? '');
        $data['status']        = trim($_POST['status'] ?? '');
        $data['notes']         = trim($_POST['notes'] ?? '');

        if ($data['vehicle_id'] <= 0) $errors['vehicle_id'] = 'Select the vehicle.';
        if ($data['service_date'] === '' || !DateTime::createFromFormat('Y-m-d', $data['service_date'])) {
            $errors['service_date'] = 'Enter a valid service date.';
        }
        if ($data['service_type'] === '') $errors['service_type'] = 'Enter the type of service performed.';
        if ($data['mechanic'] === '') $errors['mechanic'] = 'Enter the mechanic\'s name.';
        if ($data['cost'] === '' || !is_numeric($data['cost']) || (float)$data['cost'] < 0) {
            $errors['cost'] = 'Enter a valid, non-negative cost.';
        }
        if (!in_array($data['status'], $statuses, true)) {
            $errors['status'] = 'Select a valid status.';
        }

        if (empty($errors)) {
            $upd = $pdo->prepare('
                UPDATE services SET vehicle_id=?, service_date=?, service_type=?, mechanic=?, cost=?, status=?, notes=?
                WHERE id=?
            ');
            $upd->execute([
                $data['vehicle_id'], $data['service_date'], $data['service_type'],
                $data['mechanic'], (float)$data['cost'], $data['status'],
                $data['notes'] !== '' ? $data['notes'] : null, $id,
            ]);
            flash_set('success', 'Service record updated.');
            header('Location: services.php');
            exit;
        }
    }
}

$pageTitle = 'Edit Service Record';
$activeNav = 'services';
require __DIR__ . '/includes/header.php';
?>

<div class="ticket" style="max-width:680px;">
  <div class="card-body">
    <?php if (!empty($errors['general'])): ?><div class="flash error"><?= e($errors['general']) ?></div><?php endif; ?>

    <form method="post" data-validate novalidate>
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

      <div class="form-grid">
        <div class="field full">
          <label for="vehicle_id">Vehicle</label>
          <select id="vehicle_id" name="vehicle_id" data-rule="required" class="<?= isset($errors['vehicle_id']) ? 'invalid' : '' ?>">
            <?php foreach ($vehicles as $v): ?>
              <option value="<?= (int)$v['id'] ?>" <?= (string)$data['vehicle_id'] === (string)$v['id'] ? 'selected' : '' ?>>
                <?= e($v['reg_number']) ?> &mdash; <?= e($v['make']) ?> <?= e($v['model']) ?> (<?= e($v['owner_name']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
          <div class="field-error"><?= e($errors['vehicle_id'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="service_date">Service Date</label>
          <input type="date" id="service_date" name="service_date" data-rule="required"
                 class="<?= isset($errors['service_date']) ? 'invalid' : '' ?>" value="<?= e($data['service_date']) ?>">
          <div class="field-error" id="service_date-error"><?= e($errors['service_date'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="status">Status</label>
          <select id="status" name="status" data-rule="required">
            <?php foreach ($statuses as $s): ?>
              <option value="<?= e($s) ?>" <?= $data['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="field">
          <label for="service_type">Service Type</label>
          <input type="text" id="service_type" name="service_type" data-rule="required"
                 class="<?= isset($errors['service_type']) ? 'invalid' : '' ?>" value="<?= e($data['service_type']) ?>">
          <div class="field-error" id="service_type-error"><?= e($errors['service_type'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="mechanic">Mechanic</label>
          <input type="text" id="mechanic" name="mechanic" data-rule="required"
                 class="<?= isset($errors['mechanic']) ? 'invalid' : '' ?>" value="<?= e($data['mechanic']) ?>">
          <div class="field-error" id="mechanic-error"><?= e($errors['mechanic'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="cost">Cost (GH&#8373;)</label>
          <input type="number" step="0.01" min="0" id="cost" name="cost" data-rule="required|number|min:0" class="mono <?= isset($errors['cost']) ? 'invalid' : '' ?>"
                 value="<?= e($data['cost']) ?>">
          <div class="field-error" id="cost-error"><?= e($errors['cost'] ?? '') ?></div>
        </div>

        <div class="field full">
          <label for="notes">Notes (optional)</label>
          <textarea id="notes" name="notes" rows="3"><?= e($data['notes']) ?></textarea>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-amber">Update Service Record</button>
        <a href="services.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
