<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$search = trim($_GET['q'] ?? '');

$sql = '
    SELECT v.*, c.full_name AS owner_name,
           (SELECT COUNT(*) FROM services s WHERE s.vehicle_id = v.id) AS service_count
    FROM vehicles v
    JOIN customers c ON c.id = v.customer_id
';
if ($search !== '') {
    $sql .= ' WHERE v.reg_number LIKE ? OR v.make LIKE ? OR v.model LIKE ? OR c.full_name LIKE ? ';
    $stmt = $pdo->prepare($sql . ' ORDER BY v.reg_number');
    $like = "%$search%";
    $stmt->execute([$like, $like, $like, $like]);
} else {
    $stmt = $pdo->query($sql . ' ORDER BY v.reg_number');
}
$vehicles = $stmt->fetchAll();

$pageTitle = 'Vehicles';
$activeNav = 'vehicles';
require __DIR__ . '/includes/header.php';
?>

<div class="search-bar">
  <form method="get" style="display:flex; gap:10px;">
    <input type="text" name="q" placeholder="Search reg. number, make, model, or owner&hellip;" value="<?= e($search) ?>">
    <button type="submit" class="btn btn-outline">Search</button>
    <?php if ($search !== ''): ?><a href="vehicles.php" class="btn btn-outline">Clear</a><?php endif; ?>
  </form>
  <a href="vehicle_add.php" class="btn btn-amber" style="margin-left:auto;">+ Register Vehicle</a>
</div>

<div class="card">
  <div class="card-body" style="padding:0;">
    <?php if (empty($vehicles)): ?>
      <div class="empty-state">
        <div class="glyph">&#128663;</div>
        <?= $search !== '' ? 'No vehicles match your search.' : 'No vehicles registered yet.' ?>
      </div>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>Reg. Number</th><th>Make / Model</th><th>Year</th><th>Owner</th><th>Services</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($vehicles as $v): ?>
            <tr>
              <td><span class="reg-plate"><?= e($v['reg_number']) ?></span></td>
              <td><?= e($v['make']) ?> <?= e($v['model']) ?></td>
              <td><?= (int)$v['year'] ?></td>
              <td><?= e($v['owner_name']) ?></td>
              <td><?= (int)$v['service_count'] ?></td>
              <td class="row-actions">
                <a href="vehicle_edit.php?id=<?= (int)$v['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                <form method="post" action="vehicle_delete.php" onsubmit="return confirmDelete('Delete this vehicle and its service history?');" style="display:inline;">
                  <input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
                  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
