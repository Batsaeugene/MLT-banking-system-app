<?php
/**
 * Database connection (PDO / MySQL)
 * Vehicle Service Management System
 *
 * Update the constants below to match your local MySQL setup
 * (e.g. XAMPP / WAMP / MAMP defaults are host=localhost, user=root, password="").
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'vehicle_service_db');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed. Please make sure MySQL is running and '
        . 'the "vehicle_service_db" database has been imported from database.sql. '
        . 'Details: ' . htmlspecialchars($e->getMessage()));
}
