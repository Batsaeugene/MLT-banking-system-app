<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$customerCount = (int) $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn();
$vehicleCount  = (int) $pdo->query('SELECT COUNT(*) FROM vehicles')->fetchColumn();
$pendingCount  = (int) $pdo->query("SELECT COUNT(*) FROM services WHERE status IN ('Pending','In Progress')")->fetchColumn();
$revenue       = (float) $pdo->query("SELECT COALESCE(SUM(cost),0) FROM services WHERE status = 'Completed'")->fetchColumn();

$recent = $pdo->query('
    SELECT s.id, s.service_date, s.service_type, s.status, s.cost,
           v.reg_number, c.full_name AS customer_name
    FROM services s
    JOIN vehicles v ON v.id = s.vehicle_id
    JOIN customers c ON c.id = v.customer_id
    ORDER BY s.service_date DESC, s.id DESC
    LIMIT 8
')->fetchAll();

function statusBadgeClass(string $status): string
{
    return match ($status) {
        'Completed' => 'badge-completed',
        'In Progress' => 'badge-progress',
        default => 'badge-pending',
    };
}

$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
require __DIR__ . '/includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-tile">
    <div class="stat-label">Registered Customers</div>
    <div class="stat-value"><?= $customerCount ?></div>
  </div>
  <div class="stat-tile">
    <div class="stat-label">Vehicles on File</div>
    <div class="stat-value"><?= $vehicleCount ?></div>
  </div>
  <div class="stat-tile">
    <div class="stat-label">Open Service Jobs</div>
    <div class="stat-value"><?= $pendingCount ?></div>
  </div>
  <div class="stat-tile">
    <div class="stat-label">Revenue (Completed)</div>
    <div class="stat-value">GH&#8373;<?= number_format($revenue, 0) ?></div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3>Recent Service Activity</h3>
    <a href="services.php" class="btn btn-outline btn-sm">View All</a>
  </div>
  <div class="card-body" style="padding:0;">
    <?php if (empty($recent)): ?>
      <div class="empty-state">
        <div class="glyph">&#128663;</div>
        No service records yet. Add a vehicle, then log its first service.
      </div>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Date</th><th>Vehicle</th><th>Customer</th><th>Service</th><th>Status</th><th>Cost</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent as $r): ?>
            <tr>
              <td><?= e(date('d M Y', strtotime($r['service_date']))) ?></td>
              <td><span class="reg-plate"><?= e($r['reg_number']) ?></span></td>
              <td><?= e($r['customer_name']) ?></td>
              <td><?= e($r['service_type']) ?></td>
              <td><span class="badge <?= statusBadgeClass($r['status']) ?>"><?= e($r['status']) ?></span></td>
              <td class="mono">GH&#8373;<?= number_format((float)$r['cost'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
