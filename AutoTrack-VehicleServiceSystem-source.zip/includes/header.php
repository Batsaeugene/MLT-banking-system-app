<?php
/**
 * Shared page shell: <head>, sidebar navigation, topbar.
 * Expects $pageTitle and $activeNav to be set before include.
 * Expects auth.php to already be included/required by the caller.
 */
$pageTitle = $pageTitle ?? 'Dashboard';
$activeNav = $activeNav ?? '';
$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> · AutoTrack Garage</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">

  <aside class="sidebar">
    <div class="brand">
      <div class="brand-mark">Auto<span>Track</span></div>
      <div class="brand-sub">Service Centre Admin</div>
    </div>

    <nav class="nav">
      <a href="index.php" class="<?= $activeNav === 'dashboard' ? 'active' : '' ?>">
        <span class="nav-icon">&#9673;</span> Dashboard
      </a>
      <a href="customers.php" class="<?= $activeNav === 'customers' ? 'active' : '' ?>">
        <span class="nav-icon">&#9776;</span> Customers
      </a>
      <a href="vehicles.php" class="<?= $activeNav === 'vehicles' ? 'active' : '' ?>">
        <span class="nav-icon">&#9881;</span> Vehicles
      </a>
      <a href="services.php" class="<?= $activeNav === 'services' ? 'active' : '' ?>">
        <span class="nav-icon">&#128295;</span> Service Records
      </a>
    </nav>

    <div class="sidebar-footer">
      <strong><?= e($_SESSION['admin_name'] ?? 'Administrator') ?></strong>
      Logged in as admin
      <br>
      <a href="logout.php" class="logout-link">Log out &rarr;</a>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <div>
        <div class="eyebrow">AutoTrack</div>
        <h1><?= e($pageTitle) ?></h1>
      </div>
    </div>

    <div class="content">
      <?php if ($flash): ?>
        <div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
      <?php endif; ?>
