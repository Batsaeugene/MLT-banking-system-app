<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

$errors = [];
$data = ['full_name' => '', 'phone' => '', 'email' => '', 'address' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors['general'] = 'Your session expired. Please try again.';
    } else {
        $data['full_name'] = trim($_POST['full_name'] ?? '');
        $data['phone']     = trim($_POST['phone'] ?? '');
        $data['email']     = trim($_POST['email'] ?? '');
        $data['address']   = trim($_POST['address'] ?? '');

        if ($data['full_name'] === '' || mb_strlen($data['full_name']) < 2) {
            $errors['full_name'] = 'Enter the customer\'s full name.';
        }
        if (!preg_match('/^0\d{9}$/', $data['phone'])) {
            $errors['phone'] = 'Enter a valid 10-digit phone number, e.g. 0244123456.';
        }
        if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Enter a valid email address, or leave it blank.';
        }

        if (empty($errors)) {
            $dup = $pdo->prepare('SELECT id FROM customers WHERE phone = ?');
            $dup->execute([$data['phone']]);
            if ($dup->fetch()) {
                $errors['phone'] = 'A customer with this phone number is already registered.';
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare('INSERT INTO customers (full_name, phone, email, address) VALUES (?,?,?,?)');
            $stmt->execute([
                $data['full_name'],
                $data['phone'],
                $data['email'] !== '' ? $data['email'] : null,
                $data['address'] !== '' ? $data['address'] : null,
            ]);
            flash_set('success', 'Customer "' . $data['full_name'] . '" was registered.');
            header('Location: customers.php');
            exit;
        }
    }
}

$pageTitle = 'Register Customer';
$activeNav = 'customers';
require __DIR__ . '/includes/header.php';
?>

<div class="ticket" style="max-width:640px;">
  <div class="card-body">
    <?php if (!empty($errors['general'])): ?><div class="flash error"><?= e($errors['general']) ?></div><?php endif; ?>

    <form method="post" data-validate novalidate>
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

      <div class="form-grid">
        <div class="field full">
          <label for="full_name">Full Name</label>
          <input type="text" id="full_name" name="full_name" data-rule="required|minlength:2"
                 class="<?= isset($errors['full_name']) ? 'invalid' : '' ?>" value="<?= e($data['full_name']) ?>">
          <div class="field-error" id="full_name-error"><?= e($errors['full_name'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="phone">Phone Number</label>
          <input type="text" id="phone" name="phone" data-rule="required|phone" placeholder="0244123456"
                 class="<?= isset($errors['phone']) ? 'invalid' : '' ?>" value="<?= e($data['phone']) ?>">
          <div class="field-error" id="phone-error"><?= e($errors['phone'] ?? '') ?></div>
        </div>

        <div class="field">
          <label for="email">Email (optional)</label>
          <input type="email" id="email" name="email" data-rule="email"
                 class="<?= isset($errors['email']) ? 'invalid' : '' ?>" value="<?= e($data['email']) ?>">
          <div class="field-error" id="email-error"><?= e($errors['email'] ?? '') ?></div>
        </div>

        <div class="field full">
          <label for="address">Address (optional)</label>
          <input type="text" id="address" name="address" value="<?= e($data['address']) ?>">
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-amber">Save Customer</button>
        <a href="customers.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
