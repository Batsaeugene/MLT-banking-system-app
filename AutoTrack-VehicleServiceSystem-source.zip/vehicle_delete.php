<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf_token'] ?? null)) {
    $id = (int) ($_POST['id'] ?? 0);
    $stmt = $pdo->prepare('DELETE FROM vehicles WHERE id = ?');
    $stmt->execute([$id]);
    flash_set('success', 'Vehicle deleted.');
} else {
    flash_set('error', 'Could not delete vehicle. Please try again.');
}

header('Location: vehicles.php');
exit;
