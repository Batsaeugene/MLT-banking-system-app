# AutoTrack — Vehicle Service Management System

A web-based system for a local automobile service centre to register
customers, manage vehicles, and track service records. Built with
**HTML, CSS, JavaScript, PHP (PDO/MySQL), and MySQL** for BCP 206 —
Web Development Technologies II, Accra Technical University.

## Features

- **Login / Logout** for the administrator (sessions + password hashing)
- **Customer management** — register, view, edit, delete
- **Vehicle management** — register, view, edit, delete (linked to an owner)
- **Service management** — log, view, search/filter, edit, delete service
  records (date, type, mechanic, cost, status)
- **Client-side + server-side validation** on every form
- **Dashboard** with live counts and recent activity
- Protection against SQL injection (PDO prepared statements everywhere),
  XSS (output escaping via `e()`), and CSRF (per-session tokens on every
  form)

## Requirements

- PHP 8.0+
- MySQL 5.7+ / MariaDB 10.3+
- A local server stack such as XAMPP, WAMP, MAMP, or `php -S`

## Setup

1. **Create the database.** Import `database.sql` into MySQL:
   ```bash
   mysql -u root -p < database.sql
   ```
   This creates the `vehicle_service_db` database, all four tables
   (`admins`, `customers`, `vehicles`, `services`), and sample data.

2. **Configure the connection.** Open `config/db.php` and update
   `DB_HOST`, `DB_USER`, and `DB_PASS` if they differ from the XAMPP/WAMP
   defaults already set (`localhost` / `root` / empty password).

3. **Run the app.**
   - With XAMPP/WAMP: copy this folder into `htdocs/` (or `www/`) and
     visit `http://localhost/vss/`.
   - Or with PHP's built-in server, from this folder:
     ```bash
     php -S localhost:8000
     ```
     then visit `http://localhost:8000/`.

4. **Log in.**
   - Username: `admin`
   - Password: `Admin@123`

## Folder Structure

```
vss/
├── config/db.php            Database connection (PDO)
├── includes/
│   ├── auth.php             Session, login guard, CSRF, escaping helpers
│   ├── header.php           Shared layout: sidebar + topbar
│   └── footer.php           Shared layout close
├── assets/
│   ├── css/style.css        Design system / all styling
│   └── js/validation.js     Client-side form validation
├── login.php / logout.php
├── index.php                 Dashboard
├── customers.php / customer_add.php / customer_edit.php / customer_delete.php
├── vehicles.php / vehicle_add.php / vehicle_edit.php / vehicle_delete.php
├── services.php / service_add.php / service_edit.php / service_delete.php
└── database.sql             Full schema + sample data export
```

## Database Design

Four related tables:

- `admins` — system users who can log in
- `customers` — service centre clients
- `vehicles` — one-to-many with `customers` (`customer_id` FK, `ON DELETE CASCADE`)
- `services` — one-to-many with `vehicles` (`vehicle_id` FK, `ON DELETE CASCADE`)

See the ER diagram in the accompanying project report.

## Notes for the Submission Report

Take screenshots of: the login page, dashboard, customer list + add form,
vehicle list + add form, and the service records list (with a couple of
different statuses showing) + add form, after you have the app running
locally — these go into the "Screenshots of the System" section of the
report alongside the ER diagram already provided.
